Name: Thales A. Delfino
e-mail: thalesad@gmail.com
Affiliation: Universidade Federal de Ouro Preto

Name: Rodrigo Ribeiro (*)
e-mail: rodrigo.ribeiro@ufop.edu.br
Affiliation: Universidade Federal de Ouro Preto.

(*) will attend the conference to present the work.
